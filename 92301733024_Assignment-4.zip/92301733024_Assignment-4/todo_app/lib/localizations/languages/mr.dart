Map<String, String> mr = {
  "Todo List": "कामाची यादी",
  "Enter Task Name": "कार्य नाव प्रविष्ट करा",
  "All": "सर्व",
  "Pending": "प्रलंबित",
  "Completed": "संपूर्ण",
  "Select Language": "भाषा निवडा",
};
