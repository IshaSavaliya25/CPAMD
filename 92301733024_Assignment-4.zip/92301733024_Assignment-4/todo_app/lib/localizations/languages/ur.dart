Map<String, String> ur = {
  "Todo List": "ٹوڈو لسٹ",
  "Enter Task Name": "ٹاسک کا نام درج کریں۔",
  "All": "تمام",
  "Pending": "زیر التواء",
  "Completed": "مکمل",
  "Select Language": "زبان منتخب کریں۔",
};
