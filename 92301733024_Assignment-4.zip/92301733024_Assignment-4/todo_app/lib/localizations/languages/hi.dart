Map<String, String> hi = {
  "Todo List": "कार्य की सूची",
  "Enter Task Name": "काम का नाम दर्ज करें",
  "All": "सभी",
  "Pending": "बकाया",
  "Completed": "पूर्ण",
  "Select Language": "भाषा चुनें",
};
