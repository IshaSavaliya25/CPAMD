Map<String, String> gu = {
  "Todo List": "કામની યાદી",
  "Enter Task Name": "કામનું નામ દાખલ કરો",
  "All": "બધુ",
  "Pending": "બાકી",
  "Completed": "પૂર્ણ",
  "Select Language": "ભાષા પસંદ કરો",
};
