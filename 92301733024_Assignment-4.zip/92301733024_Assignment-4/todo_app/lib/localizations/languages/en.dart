Map<String, String> en = {
  "Todo List": "Todo List",
  "Enter Task Name": "Enter Task Name",
  "All": "All",
  "Pending": "Pending",
  "Completed": "Completed",
  "Select Language": "Select Language",
};
