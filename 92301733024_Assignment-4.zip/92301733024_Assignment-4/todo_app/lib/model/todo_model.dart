class TodoModel {
  bool completed;
  String task;
  int id;

  TodoModel(
    this.task,
    this.id,
    this.completed,
  );
}
