class Blog {
  String? title;
  String? description;
  String? id;
  Blog({this.title, this.description, this.id});
}
