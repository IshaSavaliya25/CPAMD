package com.example.sensor_data_analysis

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
