package com.example.daily_expense_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
