package com.example.introduction_screens

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
