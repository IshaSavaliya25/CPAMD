class Note {
  String? title;
  String? description;
  String? id;
  Note({this.title, this.description, this.id});
}
